
/*********************************************
 * GLOBAL STYLES
 *********************************************/
const Themes = {
    colors: {
        blue:'#08275a',
        blueLight:'#1d4b93',
        yellow:'#ffa91f',
        orange:'#f77b39',
        black:'#333333',
        grey:'#707070',
        lightGrey: '#ccc',
        formGrey: '#8D8D8D',
        veryLightGrey: '#eee',
        white: '#fff'
    },
    background:{
        blueToBlueLight:'linear-gradient(#08275a,#1d4b93)',
        blueLightToBlue:'linear-gradient(#1d4b93,#08275a)',
        yellowToOrange:'linear-gradient(#ffa91f,#f77b39)'
    },
    fontsize: {
        h1: "40px",
        h2: "25px",
        h3: "20px",
        p1: "20px",
        p2: "18px",
        p3: "16px",
        p4: "11px"
    },
    fontWeight: {
        light:"300",
        regular:"400",
        bold:"700",
        black:"900"
    },
    EBFont: {
        p1: "18px"
    },
    breakpoints: { 
        xs: 0,
        sm: 375,
        md: 768,
        lg: 1200,
        xl: 1980
      }
}

export default Themes;